$(window).on('scroll', function(){
   if ($(window).scrollTop()){
      $('nav').addClass('black');
   }
   else
   {
      $('nav').removeClass('black');
   }
 })

  var mapProp= {
   center:new google.maps.LatLng(-25.344490, 131.035431),
   zoom:20,
  };
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
